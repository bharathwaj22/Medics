import React from "react";
import '../assests/css/process.css';
import Header from "./Header";

import Entryprocess from "./Entryprocess";




function Process1() {
  return (
   <div className=" w-100 ">
    
      
      
   
     
      
       <Entryprocess></Entryprocess>
      
       
      
    </div>

  );
}

export default Process1;
